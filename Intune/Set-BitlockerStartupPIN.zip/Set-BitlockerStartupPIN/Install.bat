%windir%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe -WindowStyle Hidden -Executionpolicy bypass -file .\Set-BitlockerStartupPIN.ps1

