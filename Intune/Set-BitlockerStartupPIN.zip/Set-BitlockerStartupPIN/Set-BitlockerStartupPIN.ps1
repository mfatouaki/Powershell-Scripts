<#
.SYNOPSIS
    This script sets up BitLocker with a user-defined PIN on the operating system volume.
.DESCRIPTION
    Professional version: Windows Startup Style UI, DPI Aware, AAD Backup, and Intune compliance.
#>

# --- Fix for ServiceUI (Prevents blurry or stretched text) ---
$code = @'
    [DllImport("user32.dll")]
    public static extern bool SetProcessDPIAware();
'@
try {
    $type = Add-Type -MemberDefinition $code -Name "Win32Utils" -Namespace "DPI" -PassThru
    [DPI.Win32Utils]::SetProcessDPIAware()
} catch {
    # Fallback if DPI awareness cannot be set
}

# --- Configuration & Logging ---
$bitlockerFolder = "C:\Temp\Bitlocker"
if (-not (Test-Path $bitlockerFolder)) {
    New-Item -Path $bitlockerFolder -ItemType Directory -Force | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile = Join-Path $bitlockerFolder "BitLockerSetup_$timestamp.log"
$tagFile = Join-Path $bitlockerFolder "BitLockerSetupComplete.tag"

function Log-Message {
    param([string]$message)
    Write-Output "$(Get-Date) - $message"
}

function Is-PinComplex {
    param([string]$pin)
    # Check for sequential numbers
    if ($pin -match '01234|12345|23456|34567|45678|56789|67890') { return $false }
    if ($pin -match '98765|87654|76543|65432|54321|43210') { return $false }
    # Check for repeated digits
    if ($pin -match '(\d)\1{5,}') { return $false }
    # Check if all digits are the same
    if ($pin -match '^(\d)\1*$') { return $false }
    return $true
}

function Show-PinInputForm {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    # Colors
    $bkColor = [System.Drawing.Color]::FromArgb(0, 90, 158)
    $fwColor = [System.Drawing.Color]::White

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "BitLocker Drive Encryption"
    $form.WindowState = "Maximized"
    $form.FormBorderStyle = "None"
    $form.BackColor = $bkColor
    $form.TopMost = $true

    # Main Layout Container
    $lp = New-Object System.Windows.Forms.TableLayoutPanel
    $lp.Dock = "Fill"
    $lp.ColumnCount = 1
    $lp.RowCount = 8
    $lp.Padding = New-Object System.Windows.Forms.Padding(120, 80, 120, 50)
    $form.Controls.Add($lp)

    # 1. Logo (Large)
    $logoBox = New-Object System.Windows.Forms.PictureBox
    $logoBox.Size = New-Object System.Drawing.Size(400, 150)
    $logoBox.SizeMode = "Zoom"
    $logoBox.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 40)
    $logoPath = Join-Path $PSScriptRoot "Company_Logo.png"
    if (Test-Path $logoPath) {
        $logoBox.Image = [System.Drawing.Image]::FromFile($logoPath)
        $lp.Controls.Add($logoBox)
    }

    # 2. Title
    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = "BitLocker PIN Configuration"
    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI Light", 32)
    $titleLabel.ForeColor = $fwColor
    $titleLabel.AutoSize = $true
    $lp.Controls.Add($titleLabel)

    # 3. Instructions
    $instructionLabel = New-Object System.Windows.Forms.Label
    $instructionLabel.Text = "The PIN must contain at least 7 digits (numeric only) and meet complexity requirements."
    $instructionLabel.Font = New-Object System.Drawing.Font("Segoe UI", 13)
    $instructionLabel.ForeColor = $fwColor
    $instructionLabel.AutoSize = $true
    $instructionLabel.Margin = New-Object System.Windows.Forms.Padding(0, 10, 0, 40)
    $lp.Controls.Add($instructionLabel)

    # 4. PIN Input
    $pinInput = New-Object System.Windows.Forms.TextBox
    $pinInput.PasswordChar = "*"
    $pinInput.Font = New-Object System.Drawing.Font("Segoe UI", 18)
    $pinInput.Width = 400
    $pinInput.BorderStyle = "FixedSingle"
    $lp.Controls.Add($pinInput)

    # 5. PIN Confirmation
    $pinConfirmInput = New-Object System.Windows.Forms.TextBox
    $pinConfirmInput.PasswordChar = "*"
    $pinConfirmInput.Font = New-Object System.Drawing.Font("Segoe UI", 18)
    $pinConfirmInput.Width = 400
    $pinConfirmInput.BorderStyle = "FixedSingle"
    $pinConfirmInput.Margin = New-Object System.Windows.Forms.Padding(0, 15, 0, 0)
    $lp.Controls.Add($pinConfirmInput)

    # 6. Show PIN Checkbox
    $showPinCheck = New-Object System.Windows.Forms.CheckBox
    $showPinCheck.Text = "Show PIN"
    $showPinCheck.Font = New-Object System.Drawing.Font("Segoe UI", 11)
    $showPinCheck.ForeColor = $fwColor
    $showPinCheck.AutoSize = $true
    $showPinCheck.Margin = New-Object System.Windows.Forms.Padding(0, 10, 0, 30)
    $showPinCheck.Add_CheckedChanged({
        $char = if ($showPinCheck.Checked) { $null } else { "*" }
        $pinInput.PasswordChar = $char
        $pinConfirmInput.PasswordChar = $char
    })
    $lp.Controls.Add($showPinCheck)

    # 7. Button and Error Area
    $bottomFlow = New-Object System.Windows.Forms.FlowLayoutPanel
    $bottomFlow.AutoSize = $true
    $bottomFlow.FlowDirection = "LeftToRight"
    
    $submitButton = New-Object System.Windows.Forms.Button
    $submitButton.Text = "Set PIN"
    $submitButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 12)
    $submitButton.ForeColor = $fwColor
    $submitButton.FlatStyle = "Flat"
    $submitButton.Size = New-Object System.Drawing.Size(160, 50)
    $submitButton.Cursor = [System.Windows.Forms.Cursors]::Hand
    $bottomFlow.Controls.Add($submitButton)

    $errorLabel = New-Object System.Windows.Forms.Label
    $errorLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 190, 190)
    $errorLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
    $errorLabel.AutoSize = $true
    $errorLabel.Margin = New-Object System.Windows.Forms.Padding(25, 12, 0, 0)
    $bottomFlow.Controls.Add($errorLabel)
    
    $lp.Controls.Add($bottomFlow)

    $script:pin = $null
    $submitButton.Add_Click({
        $p1 = $pinInput.Text
        $p2 = $pinConfirmInput.Text
        if ($p1.Length -ge 7 -and $p1 -match '^\d+$' -and $p1 -eq $p2) {
            if (Is-PinComplex $p1) {
                $script:pin = $p1
                Log-Message "User PIN successfully validated."
                $form.Close()
            } else { $errorLabel.Text = "Error: PIN is too simple." }
        } elseif ($p1 -ne $p2) { $errorLabel.Text = "Error: PINs do not match." }
        else { $errorLabel.Text = "Error: Use at least 7 digits (numbers only)." }
    })

    $form.AcceptButton = $submitButton
    $form.Add_Shown({$form.Activate(); $pinInput.Focus()})
    [void]$form.ShowDialog()

    return $script:pin
}

# --- Main Execution ---
Try {
    Start-Transcript -Path $logFile -Append

    $osVolume = Get-BitLockerVolume | Where-Object { $_.VolumeType -eq 'OperatingSystem' }

    # Remove existing PIN protectors if any
    if ($osVolume.KeyProtector.KeyProtectorType -contains 'TpmPin') {
        Log-Message "Removing existing PIN protector..."
        $osVolume.KeyProtector | Where-Object { $_.KeyProtectorType -eq 'TpmPin' } | ForEach-Object {
            Remove-BitLockerKeyProtector -MountPoint $osVolume.MountPoint -KeyProtectorId $_.KeyProtectorId
        }
    }

    # Ensure Recovery Password exists
    if ($osVolume.KeyProtector.KeyProtectorType -notcontains 'RecoveryPassword') {
        Log-Message "Enabling Recovery Password protector..."
        Enable-BitLocker -MountPoint $osVolume.MountPoint -RecoveryPasswordProtector
    }

    # Show the GUI
    $userPIN = Show-PinInputForm

    if (-not $userPIN) {
        Log-Message "Input cancelled or empty. Aborting."
        throw "User closed the window without entering a PIN."
    }

    # Apply the PIN
    $devicePIN = ConvertTo-SecureString $userPIN -AsPlainText -Force
    Log-Message "Applying new PIN (7+ digits)..."
    Enable-BitLocker -MountPoint $osVolume.MountPoint -Pin $devicePIN -TpmAndPinProtector -ErrorAction Stop

    # Backup Recovery Key to Azure AD
    Log-Message "Backing up recovery key to Azure AD..."
    $updatedVolume = Get-BitLockerVolume | Where-Object { $_.VolumeType -eq 'OperatingSystem' }
    $updatedVolume.KeyProtector | Where-Object { $_.KeyProtectorType -eq 'RecoveryPassword' } | ForEach-Object {
        BackupToAAD-BitLockerKeyProtector -MountPoint $osVolume.MountPoint -KeyProtectorId $_.KeyProtectorId
    }

    Log-Message "BitLocker setup completed successfully."
    New-Item -Path $tagFile -ItemType File -Force | Out-Null
    
    Stop-Transcript
    Exit 0
}
Catch {
    $ErrorMessage = $_.Exception.Message
    Log-Message "ERROR: $ErrorMessage"
    Stop-Transcript
    Exit 1
}