$ProcessActive = Get-Process "WWAHost" -ErrorAction silentlycontinue
if ($null -eq $ProcessActive) { Write-Output "True" } else { Write-Output "False" }
